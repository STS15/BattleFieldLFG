var mysql = require('mysql');
var conn = mysql.createConnection({
    host: "localhost",
    user: "website",
    password: "website",
    database: "haloinfinitelfg"
});

conn.connect(function(err) {
    if (err) throw err;
    console.log('Database is connected successfully!');
});

module.exports = conn;
